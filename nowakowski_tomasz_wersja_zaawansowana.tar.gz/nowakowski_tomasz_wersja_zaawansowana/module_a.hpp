#include <string>


void display_module_a_menu();
std::string handle_module_a_menu();
