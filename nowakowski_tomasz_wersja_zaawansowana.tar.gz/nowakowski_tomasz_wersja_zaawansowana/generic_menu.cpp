/*
File `generic_menu.cpp` contains functions related to displaying menus.
*/


#include <iostream>
// It would be better to use map instead of vector,
// as it would allow to pair number codes and strings
// more closely.
#include <vector>

#include "generic_menu.hpp"


void display_menu(std::string header, std::vector<std::string> options) {
    /*
    Function `display_menu` is a generic-ish function that is used
    by all menus used in this app to write menu options and headers.

    Arguments
    ---------
    header : str::string
        Header of the menu. Will be displayed at the top.

    options : std::vector
        Vector of all options available to choose from.

    Returns
    -------
    void
    */

    std::cout << std::endl;
    std::cout << header << std::endl;
    for (unsigned int i = 0; i < options.size(); i++) {
        std::cout << i << " - " << options[i] << std::endl;
    }
}
