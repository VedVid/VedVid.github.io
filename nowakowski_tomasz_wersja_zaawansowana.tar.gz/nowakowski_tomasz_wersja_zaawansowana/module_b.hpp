#include <string>


void display_module_b_menu();
std::string handle_module_b_menu();
