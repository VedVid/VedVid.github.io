/*
File `module_d.cpp` implements Module D, which
provides functionality related to converting the temperature
from Fahrenheit to Celsius and from Celsius to Fahrenheit.
*/


#include <iomanip>
#include <iostream>
#include <sstream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "module_d.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_module_d = name_module_d;


std::vector<std::string> options_module_d = {
    "Powrot",
    "Konwersja ze stopni Fahrenheita do stopni Celsjusza (podstawowa)",
    "Konwersja ze stopni Celsjusza do stopni Fahrenheita (podstawowa)",
    "Konwersja ze stopni Fahrenheita do stopni Celsjusza (zaawansowana)",
    "Konwersja ze stopni Celsjusza do stopni Fahrenheita (zaawansowana)"
};


void display_module_d_menu() {
    /*
    Function `display_module_d_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_module_d, options_module_d);
}


std::string basic_conversion(int operation) {
    /*
    Function `basic_conversion` converts a temperature between
    Celsius and Fahrenheit scale.
    The program asks user to provide a single value of temperature,
    then provides a list of 5 consecutive temperatures, with a
    clearly marked user input in the middle.

    Arguments
    ---------
    operation : int
        `1` stands for conversion from Fahrenheit to Celsius;
        `2` stands for conversion from Celsius to Fahrenheit.

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_d.
        This is later passed to `handle_module_d_menu`.
        TODO: Create a new type for states.
    */

    int default_precision = std::cout.precision();
    std::ostringstream oss;

    switch (operation) {
    case 0:
        return state_main_menu;
    case 1:
        std::cout << "Wprowadz temperature w stopniach Fahrenheita: " << std::endl;
        break;
    case 2:
        std::cout << "Wprowadz temperature w stopniach Celsjusza: " << std::endl;
        break;
    }

    int input_temperature = read_data_input(true);

    // Calculations, printing, history
    switch (operation) {
    case 1:
        oss << input_temperature << "*F = " << (input_temperature - 32) * (5.0 / 9) << "*C";
        add_to_history(oss.str());
        oss.str("");
        std::cout << std::fixed << std::setprecision(1) << input_temperature-2 << "*F = " << (input_temperature - 2 - 32) * (5.0 / 9) << "*C" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature-1 << "*F = " << (input_temperature - 1 - 32) * (5.0 / 9) << "*C" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << ">>  " << input_temperature << "*F = " << (input_temperature - 32) * (5.0 / 9) << "*C" << "  <<" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature+1 << "*F = " << (input_temperature + 1 - 32) * (5.0 / 9) << "*C" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature+2 << "*F = " << (input_temperature + 2 - 32) * (5.0 / 9) << "*C" << std::endl;
        break;
    case 2:
        oss << input_temperature << "*C = " << input_temperature * (9.0 / 5) + 32 << "*F";
        add_to_history(oss.str());
        oss.str("");
        std::cout << std::fixed << std::setprecision(1) << input_temperature-2 << "*C = " << (input_temperature - 2) * (9.0 / 5) + 32 << "*F" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature-1 << "*C = " << (input_temperature - 1) * (9.0 / 5) + 32 << "*F" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << ">>  " << input_temperature << "*C = " << input_temperature * (9.0 / 5) + 32 << "*F" << "  <<" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature+1 << "*C = " << (input_temperature + 1) * (9.0 / 5) + 32 << "*F" << std::endl;
        std::cout << std::fixed << std::setprecision(1) << input_temperature+2 << "*C = " << (input_temperature + 2) * (9.0 / 5) + 32 << "*F" << std::endl;
        break;
    }

    std::setprecision(default_precision);
    return state_module_d;
}


std::string range_conversion(int operation) {
    /*
    Function `range_conversion` converts a temperature between
    Celsius and Fahrenheit scale, over the user-defined range.
    The program asks user to provide a lower bound of temperature,
    upper bound of temperature, and step.
    This function ends prematurely if the step do not match the range.
    Numbers used for `operation` argument are 3 and 4 because the numbers
    are used inside the switch statement indicate not only if conversion
    is from F to C or from C to F, but also if the program will use
    basic conversion or conversion over range.

    Arguments
    ---------
    operation : int
        `3` stands for conversion from Fahrenheit to Celsius;
        `4` stands for conversion from Celsius to Fahrenheit.

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_d.
        This is later passed to `handle_module_d_menu`.
        TODO: Create a new type for states.
    */

    int default_precision = std::cout.precision();
    int low_range_bound;
    int high_range_bound;
    int step;
    std::ostringstream oss;

    std::string scale_s = " Fahrenheita: ";
    if (operation == 4) {
        scale_s = " Celsjusza: ";
    }

    std::cout << "Wprowadz dolna granice temperatury w stopniach" << scale_s << std::endl;
    low_range_bound = read_data_input(true);
    std::cout << "Wprowadz gorna granice temperatury w stopniach" << scale_s << std::endl;
    high_range_bound = read_data_input(true);
    std::cout << "Wprowadz krok pomiarow w stopniach" << scale_s << std::endl;
    step = read_data_input(true);

    // Handling input errors
    bool basic = false;
    if (low_range_bound > high_range_bound) {
        std::cout << "Dolna wartosc temperatury jest wyzsza od gornej. Dokonano zamiany." << std::endl;
        int temp_bound = high_range_bound;
        high_range_bound = low_range_bound;
        low_range_bound = temp_bound;
    } else if (low_range_bound == high_range_bound) {
        std::cout << "Dolna i gorna wartosc temperatury sa takie same. Zostanie dokonana pojedyncza konwersja." << std::endl;
    }
    if ((high_range_bound - low_range_bound) % step != 0) {
        std::cout << "Wprowadzono nieprawidlowy krok. Rozpocznij od nowa." << std::endl;
        std::cout << "    (" << high_range_bound << " - " << low_range_bound << ") % " << step << " != 0" << std::endl;
        return state_module_d;
    }

    // Calculations, printing, history
    switch (operation) {
    case 3:
        {
            for(int i = low_range_bound; i <= high_range_bound; i += step) {
                oss << i << "*F = " << (i - 32) * (5.0 / 9) << "*C";
                std::cout << oss.str() << std::endl;
                add_to_history(oss.str());
                add_to_module(name_module_d, false, oss.str());
                oss.str("");
            }
        break;
        }
    case 4:
        {
            for(int i = low_range_bound; i <= high_range_bound; i += step) {
                oss << i << "*C = " << i * (9.0 / 5) + 32 << "*F";
                std::cout << oss.str() << std::endl;
                add_to_history(oss.str());
                add_to_module(name_module_d, false, oss.str());
                oss.str("");
            }
        break;
        }
    }

    std::setprecision(default_precision);
    return state_module_d;
}


std::string handle_module_d_menu() {
    /*
    Function `handle_module_d_menu` takes player input, and calls either
    function that performs basic conversion (single input value) or
    conversion over range (user specifies lower bound, upper bound, and step).

    Arguments
    ---------
    None

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_d.
        TODO: Create a new type for states.
    */

    // Input
    std::cout << "Wybierz operacje: " << std::endl;
    int operation = read_options_input(options_module_d.size());
    if (operation == 0) {
        return state_main_menu;
    } else if (operation == 1 || operation == 2) {
        return basic_conversion(operation);
    } else {
        return range_conversion(operation);
    }
}
