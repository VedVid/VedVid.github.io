#include <string>


void display_main_menu();
std::string handle_main_menu();
