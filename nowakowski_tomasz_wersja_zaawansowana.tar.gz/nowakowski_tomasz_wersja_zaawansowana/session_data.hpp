#include <string>
#include <vector>


void add_to_history(std::string);
void print_all_history();
void add_to_module(std::string, bool, std::string);
void print_modules();
