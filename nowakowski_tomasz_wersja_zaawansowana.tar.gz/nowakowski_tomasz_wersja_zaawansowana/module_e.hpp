#include <string>


void display_module_e_menu();
std::string handle_module_e_menu();
