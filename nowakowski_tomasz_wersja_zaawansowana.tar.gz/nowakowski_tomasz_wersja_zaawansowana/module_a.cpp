/*
File `module_a` implements the Module A, which
provides functionality related to basic operations
on two numbers.
*/


#include <iostream>
#include <sstream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "module_a.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_module_a = name_module_a;

std::vector<std::string> options_module_a = {
    "Powrot",
    "Suma",
    "Roznica",
    "Iloczyn",
    "Iloraz",
    "Reszta z dzielenia"
};


void display_module_a_menu() {
    /*
    Function `display_module_a_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_module_a, options_module_a);
}


std::string handle_module_a_menu() {
    /*
    Function `handle_module_a_menu` handles user input for this module,
    and performs all calculations, such as modulo, division, and so on.
    At first, it asks user to choose what kind of calculation would they
    want to perform, and only after that it asks user to provide numbers.
    In addition, every calculation is added to the sessions history
    stored in `session_data.cpp`.

    Arguments
    ---------
    None

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_a.
        TODO: Create a new type for states.
    */
    int n1;
    int n2;
    int operation;
    int result = 0;
    std::string operation_symbol;

    // Input
    std::cout << "Wybierz dzialanie: " << std::endl;
    operation = read_options_input(options_module_a.size());
    if (operation == 0) {
        return state_main_menu;
    }
    std::cout << "Wprowadz pierwsza liczbe: " << std::endl;
    n1 = read_data_input(true);
    std::cout << "Wprowadz druga liczbe: " << std::endl;
    n2 = read_data_input(true);

    // Calculations
    switch (operation) {
    case 1:
        operation_symbol = " + ";
        result = n1 + n2;
        break;
    case 2:
        operation_symbol = " - ";
        result = n1 - n2;
        break;
    case 3:
        operation_symbol = " * ";
        result = n1 * n2;
        break;
    case 4:
        if (n2 == 0) {
            std::cout << "Dzielnik nie moze byc zerem!" << std::endl;
            return state_module_a;
        } else if (n1 % n2 != 0) {
            std::cout << "Uwaga, wspieramy tylko dzielenie calkowite!" << std::endl;
        }
        operation_symbol = " / ";
        result = n1 / n2;
        break;
    case 5:
        if (n2 == 0) {
            std::cout << "Dzielnik nie moze byc zerem!" << std::endl;
            return state_module_a;
        } else if (n1 % n2 != 0) {
            std::cout << "Uwaga, wspieramy tylko dzielenie calkowite!" << std::endl;
        }
        operation_symbol = " % ";
        result = n1 % n2;
        break;
    }

    // Printing and history
    std::ostringstream oss;
    oss << n1 << operation_symbol << n2 << " = " << result;
    add_to_history(oss.str());
    add_to_module(name_module_a, false, oss.str());
    oss.str("");
    std::cout << n1 << operation_symbol << n2 << " = " << result << std::endl;

    return state_module_a;
}
