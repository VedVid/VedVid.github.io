/*
File `states.cpp` definies all states used by the app
in a single place, in order to allow modifying them
in an easy way globally if needed.
*/


#include <string>


const std::string state_main_menu = "main menu";
const std::string state_module_a = "module a";
const std::string state_module_b = "module b";
const std::string state_module_c = "module c";
const std::string state_module_d = "module d";
const std::string state_module_e = "module e";
const std::string state_exit = "exit";
