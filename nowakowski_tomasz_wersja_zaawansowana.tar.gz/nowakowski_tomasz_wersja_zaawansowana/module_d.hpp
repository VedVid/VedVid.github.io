#include <string>


void display_module_d_menu();
std::string basic_conversion(int);
std::string range_conversion(int);
std::string handle_module_d_menu();

