int read_options_input(int options_size);
int read_data_input(bool allow_negative);
double read_grades_input();
