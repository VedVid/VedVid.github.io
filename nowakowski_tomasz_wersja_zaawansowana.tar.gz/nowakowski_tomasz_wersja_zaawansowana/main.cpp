/*
Program "Asystent analizy danych" jest projektem zaliczeniowym
wykonanym w ramach przedmiotu "Podstawy programowania" prowadzonego
przez mgr inż. Pawła Krzyżanowskiego.

Zakres projektu obejmuje pięć modułów:
- operacje na dwu liczbach
- gemetrię
- oceny
- konwersję temperatur
- raport z sesji
a także dokumentację techniczną oraz zestaw testów.

Autor: Tomasz Nowakowski, I rok informatyki.
*/


#include <iostream>

#include "main_menu.hpp"
#include "module_a.hpp"
#include "module_b.hpp"
#include "module_c.hpp"
#include "module_d.hpp"
#include "module_e.hpp"
#include "states.cpp"


int main()
{
    std::cout << " _____ _____ __ __ _____ _____ _____ _____ _____ " << std::endl;
    std::cout << "|  _  |   __|  |  |   __|_   _|   __|   | |_   _|" << std::endl;
    std::cout << "|     |__   |_   _|__   | | | |   __| | | | | |  " << std::endl;
    std::cout << "|__|__|_____| |_| |_____| |_| |_____|_|___| |_|  " << std::endl;
    std::cout << std::endl;

    std::string state = state_main_menu;

    while(true) {
        if (state == state_main_menu) {
            display_main_menu();
            state = handle_main_menu();
        } else if (state == state_module_a) {
            display_module_a_menu();
            state = handle_module_a_menu();
        } else if (state == state_module_b) {
            display_module_b_menu();
            state = handle_module_b_menu();
        } else if (state == state_module_c) {
            display_module_c_menu();
            state = handle_module_c_menu();
        } else if (state == state_module_d) {
            display_module_d_menu();
            state = handle_module_d_menu();
        } else if (state == state_module_e) {
            display_module_e_menu();
            state = handle_module_e_menu();
        } else if (state == state_exit) {
            break;
        }
    }

    return 0;
}
