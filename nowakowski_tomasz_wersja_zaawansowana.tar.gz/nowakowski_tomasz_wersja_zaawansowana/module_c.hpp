#include <string>


void display_module_c_menu();
std::string handle_module_c_menu();
