void display_menu(std::string header, std::vector<std::string> options);
