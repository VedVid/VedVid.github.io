/*
File `main_menu.cpp` definies main app menu:
- its header,
- all options available to choose,
- handling user choosing specific option.
*/


#include <iostream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "main_menu.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_main_menu = "Wybierz modul, ktorego chcesz uzyc:";
std::vector<std::string> options_main_menu = {
    "Wyjdz z programu",
    "Operacje na dwu liczbach",
    "Geometria",
    "Oceny",
    "Konwersja temperatur",
    "Raport sesji"
};


void display_main_menu() {
    /*
    Function `display_main_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_main_menu, options_main_menu);
}


std::string handle_main_menu() {
    /*
    Function `handle_main_menu` reads user input,
    increases amount of visits to the chosen module,
    then returns state of the chose module, effectively
    switching view to the module.
    `add_to_module` calls are here because, due to the
    current architecture, putting them in `module_foo.handle_menu`
    would increase amount of visits to the module
    every time when the menu is displayed, instead of
    increasing it only on enter.

    Arguments
    ---------
    None

    Returns
    -------
    std::string
    */

    int chosen = read_options_input(options_main_menu.size());

    switch (chosen) {
    case 0:
        std::cout << "Probujesz wyjsc z programu" << std::endl;
        return state_exit;
    case 1:
        add_to_module(name_module_a, true, "");
        return state_module_a;
    case 2:
        add_to_module(name_module_b, true, "");
        return state_module_b;
    case 3:
        add_to_module(name_module_c, true, "");
        return state_module_c;
    case 4:
        add_to_module(name_module_d, true, "");
        return state_module_d;
    case 5:
        return state_module_e;
    default:
        std::cout << "Nieprawidlowa dana. Prosze, wybierz liczbe z zakresu 0-5." << std::endl;
        std::cout << "This should never happen, as the input is validated inside `handle_input.cpp`.";
        break;
    }

    return state_main_menu;
}
