/*
File `module_e.cpp` implements Module E, which
tracks the session history and prints it.
The history data is stored in `session_data.cpp`.
*/


#include <iomanip>
#include <iostream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "module_e.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_module_e = name_module_e;

std::vector<std::string> options_module_e = {
    "Powrot",
    "Pokaz pelen raport",
    "Pokaz dane modulow"
};


void display_module_e_menu() {
    /*
    Function `display_module_e_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_module_e, options_module_e);
}


std::string handle_module_e_menu() {
    /*
    Function `handle_module_e_menu` handles user input for this module,
    and calls functions that print either a complete history of calculations
    performed during a session, or last calculation performed for every module.

    Arguments
    ---------
    None

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_e.
        TODO: Create a new type for states.
    */

    int operation;
    std::cout << "Wybierz operacje: " << std::endl;
    operation = read_options_input(options_module_e.size());

    switch (operation) {
    case 0:
        return state_main_menu;
    case 1:
        print_all_history();
        break;
    case 2:
        print_modules();
        break;
    }

    return state_module_e;
}
