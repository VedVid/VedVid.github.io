/*
File `session_data.cpp` contains functionality related
to tracking user journey, namely history of calculations
and launched modules.
*/


#include <iostream>
#include <map>
#include <string>
#include <tuple>
#include <vector>

#include "module_names.cpp"
#include "session_data.hpp"


// All calculations
std::vector<std::string> history = {};

std::map<std::string, std::tuple<int, std::string>> modules_history = {
    // Module name, tuple of (how_many_times_module_was_started, last_calculation)
    {name_module_a, std::make_tuple(0, "")},
    {name_module_b, std::make_tuple(0, "")},
    {name_module_c, std::make_tuple(0, "")},
    {name_module_d, std::make_tuple(0, "")}
};


void add_to_history(std::string element) {
    /*
    Function `add_to_history` adds a string element to the end of the `history`
    vector. The pushed element is usually a last calculation perfomed by a module.
    TODO: this function and `add_to_module` could be merged which would
    remove some clutter from implementations of `handle_module_foo_menu`.

    Arguments
    ---------
    element : std::string
        String that is going to be added to the `history` vector. Usually it's
        a string representation of last performed calculation by a module.

    Returns
    -------
    void
    */

    history.push_back(element);
}


void print_all_history() {
    /*
    Function `print_all_history` prints all calculations stored in the `history` vector.
    Since `add_to_history` pushes new elements to the back of the vector,
    `print_all_history` will print the oldest calculations at the top.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    if (history.size() == 0) {
        std::cout << "Zadne kalkulacje nie zostaly jeszcze przeprowadzone." << std::endl;
    } else {
        for (unsigned int i = 0; i < history.size(); i++) {
            std::cout << history[i] << std::endl;
        }
    }
}


void add_to_module(std::string current_module, bool increase, std::string calculation_string) {
    /*
    Function `add_to_module` adds the data to the history of specific module which is
    stored in `modules_history` declared near the top of this file. Please see the comment
    there to learn more about the data structures used there.
    You can use this function to just increase the amount of visits in the modules;
    to do so, you need to pass a module name to `current_module`, `true` to `increase, and empty
    string to `calculation_string`.
    Please note that the `calculation_string`, unless empty, will always
    replace the last performed calculation stored in `modules_history`. This is by design,
    as we use this variable when we are interested in the last performed calculation
    per module. You should pass `false` to `increase` if you want to just replace the calculations.
    You always must pass a correct module name.
    For a whole history of calculations, please see `add_to_history` function.

    TODO: This function should be split into at least two, if not three separate, smaller function:
    - one to increase the visits counter
    - second to replace calculation string
    - and perhaps separate function for proper validation of module name

    Examples
    --------
    add_to_module("Module 0 - Test module", false, "2+2=4");
        This increases a counter of visits of Module 0, and sets
        the last performed calculation to 2+2=4.

    add_to_module("Module 0 - Test module", true, "");
        This increases a counter of visits of Module 0, but does not
        replace the last performed calculation.
        This form of call is used typically when


    Arguments
    ---------
    current_module : std::string
        Name of the module, as declared in `module_names.cpp`.
    increase : bool
        `true` will increase visists counter for specific module.
    calculation_string : std::string
        Last calculation performed in a module. Can be empty.
        TODO: Could be set with default argument of `""`.

    Returns
    -------
    void
    */

    if (increase) {
        std::get<0>(modules_history[current_module]) += 1;
    }
    if (!calculation_string.empty()) {
        std::get<1>(modules_history[current_module]) = calculation_string;
    }
}


void print_modules() {
    /*
    Function `print_modules` prints amount of visits to a every module,
    and the last performed calculation performed in each. It is possible
    that user visited the module but did not perform any calculations.

    `all_modules` declares a vector of all modules used in app, with
    exception for the history module. In theory, I could use `modules_history`
    declared near the top of the file here, but it is a map which is not
    guaranteed to be ordered - and I wanted to keep the modules in order.
    Hence local vector here.

    Argments
    --------
    None

    Returns
    -------
    void
    */

    std::vector<std::string> all_modules = {
        name_module_a,
        name_module_b,
        name_module_c,
        name_module_d
    };

    for (std::string element : all_modules) {
        int called_no = std::get<0>(modules_history[element]);
        std::string last_calculation = std::get<1>(modules_history[element]);
        std::cout << element << " byl wywolany " << called_no << " raz(y)." << std::endl;
        if (!last_calculation.empty()) {
            std::cout << "    Ostatnia kalkulacja to: " << last_calculation << std::endl;
        } else {
            std::cout << "    Zadne obliczenia nie zostaly przeprowadzone." << std::endl;
        }
    }
}
