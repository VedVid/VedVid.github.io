/*
In file `module_names.cpp` the module names are stored.
These are used as a menu headers for their corresponding modules,
and for storing and printing history data.
*/


#include <string>


const std::string name_module_a = "Modul A - operacje na dwu liczbach";
const std::string name_module_b = "Modul B - geometria";
const std::string name_module_c = "Modul C - oceny";
const std::string name_module_d = "Modul D - konwersja temperatur";
const std::string name_module_e = "Modul E - raport sesji";
