/*
File `handle_input.cpp` contains functions used by all modules
to handle user input, such as choosing menu option, or entering grades.
*/


#include <algorithm>
#include <limits>
#include <iostream>
#include <vector>

#include "handle_input.hpp"


int read_options_input(int options_size) {
    /*
    Function `read_options_input` takes user input, validates it, and returns if the input is valid.

    Arguments
    ---------
    options_size : int
        Amount of options available to choose from.

    Returns
    -------
    int
        User's input, it indicates what option user chose.
    */

    int input;

    while (true) {
        // It's supposed to make sure that the input is actually int.
        // It isn't a flawless solution though, as user can input string with a valid integer
        // as a first character, and the input will be treated as valid one.
        if (!(std::cin >> input)) {
            std::cout << "Nieprawidlowa dana. Prosze wprowadz liczbe." << std::endl;
        } else if (input < 0 || input >= options_size) {
            std::cout << "Nieprawidlowa dana. Prosze wprowadz liczbe od 0 do " << options_size - 1 << "." << std::endl;
        } else {
            break;
        }
        // Necessary to avoid potentially infinity loop in case of invalid input.
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Necessary to print error message only once for multi-character input.
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    return input;
}


int read_data_input(bool allow_negative) {
    /*
    Function `read_data_input` takes user input, validates it, and returns if the input is valid.
    In comparison to `read_options_input`, it's more _liberal_ regarding input validation.
    It also can be explicitely set to allow or disallow negative input – it helps to
    use the same function for e.g. gemetry and temperature conversion, without
    the need for separate input validation in code of modules.

    Arguments
    ---------
    allow_negative : bool
        Actually, allow_negative set to false disallows not only using negative
        values, but also disallows using 0.

    Returns
    -------
    int
        User's input, data that will be used for calculations.
    */

    int input;

    while (true) {
        // It's supposed to make sure that the input is actually int.
        // It isn't a flawless solution though, as user can input string with a valid integer
        // as a first character, and the input will be treated as valid one.
        if (!(std::cin >> input)) {
            std::cout << "Nieprawidlowa dana. Prosze wprowadz liczbe." << std::endl;
        } else if (!allow_negative && input <= 0) {
            std::cout << "Nieprawidlowa dana. Prosze wprowadz liczbe wieksza od zera." << std::endl;
        } else {
            break;
        }
        // Necessary to avoid potentially infinity loop in case of invalid input.
        std::cin.clear();
        std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');
    }

    // Necessary to print error message only once for multi-character input.
    std::cin.clear();
    std::cin.ignore(std::numeric_limits<std::streamsize>::max(), '\n');

    return input;
}


double read_grades_input() {
    /*
    Function `read_grades_input` takes user input, validates it, and returns if the input is valid.
    This function is used only to read grades, so the input must be one of the possible
    grades on university, as specified below in `valid_input` vector.

    Arguments
    ---------
    None

    Returns
    -------
    double
        User's input, his or hers grade.
    */

    double input;
    std::vector<double> valid_input = {2.0, 2.5, 3.0, 3.5, 4.0, 4.5, 5.0};

    while ((!(std::cin >> input)) || (!std::count(valid_input.begin(), valid_input.end(), input))) {
        std::cout << "Nieprawidlowa dana. Prosze, wpisz liczbe w zakresie 2.0 - 5.0." << std::endl;
        std::cin.clear();
        std::cin.ignore();
    }

    return input;
}
