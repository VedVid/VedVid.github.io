/*
File `module_b.cpp` implements the Module B, which
provides functionality related to geometry calculations.
Currently, only the area and perimeter of a rectangle.
*/


#include <iostream>
#include <sstream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "module_b.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_module_b = name_module_b;

std::vector<std::string> options_module_b = {
    "Powrot",
    "Obwod prostokata",
    "Pole prostokata"
};


void display_module_b_menu() {
    /*
    Function `display_module_b_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_module_b, options_module_b);
}


std::string handle_module_b_menu() {
    /*
    Function `handle_module_b_menu` handles user input for this module,
    and performs all calculations: perimeter and area of a given rectangle.
    User specifies the rectangle data only after choosing a calculation
    to perform.
    In addition, every calculation is added to the sessions history
    stored in `session_data.cpp`.

    Arguments
    ---------
    None

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_b.
        TODO: Create a new type for states.
    */

    int w;
    int h;
    int operation;

    // Input
    std::cout << "Wybierz dzialanie: " << std::endl;
    operation = read_options_input(options_module_b.size());
    if (operation == 0) {
        return state_main_menu;
    }
    std::cout << "Wprowadz szerokosc prostokata: " << std::endl;
    w = read_data_input(false);
    std::cout << "Wprowadz wysokosc prostokata: " << std::endl;
    h = read_data_input(false);
    std::ostringstream oss;

    // Calculations and printing
    switch (operation) {
    case 1:
        std::cout << "Obwod prostokata o bokach o dlugosci " << w << " oraz " << h << " jednostek wynosi: " << std::endl;
        oss << "Obwod prostokata: " << "2 * (" << w << " + " << h << ") = " << 2 * (w + h) << " jednostek";
        std::cout << "2 * (" << w << " + " << h << ") = " << 2 * (w + h) << " jednostek" << std::endl;
        break;
    case 2:
        std::cout << "Pole prostokata o bokach o dlugosci " << w << " oraz " << h << " jednostek wynosi: " << std::endl;
        oss << "Pole prostokata: " << w << " * " << h << " = " << w*h << " jednostek^2";
        std::cout << w << " * " << h << " = " << w*h << " jednostek^2" << std::endl;
        break;
    }

    // History
    add_to_history(oss.str());
    add_to_module(name_module_b, false, oss.str());
    oss.str("");

    return state_module_b;
}

