/*
File `module_c.cpp` implements Module C, which
provides functionality related to working with
user's grades.
*/


#include <algorithm>
#include <iostream>
#include <sstream>
#include <vector>

#include "generic_menu.hpp"
#include "handle_input.hpp"
#include "module_c.hpp"
#include "session_data.hpp"
#include "module_names.cpp"
#include "states.cpp"


std::string header_module_c = name_module_c;

std::vector<std::string> options_module_c = {
    "Powrot",
    "Wprowadz nowe oceny (Uwaga! Kasuje wczesniej wpisane oceny!)",
    "Srednia",
    "Najnizsza ocena",
    "Najwyzsza ocena",
    "Liczba ocen ponizej 3.0"
};

std::vector<double> grades = {};


void display_module_c_menu() {
    /*
    Function `display_module_c_menu` calls `display_menu` from `generic_menu.cpp`,
    passing the specified in this file header and options as arguments.

    Arguments
    ---------
    None

    Returns
    -------
    void
    */

    display_menu(header_module_c, options_module_c);
}


std::string handle_module_c_menu() {
    /*
    Function `handle_module_c_menu` handles user input for this module,
    and performs all operations, such as adding grades to container,
    calculating average,and so on.
    At first, user must add at least three grades using the first menu.
    Without grades in vector, all other operations are unavailable.
    In addition, every calculation is added to the sessions history
    stored in `session_data.cpp`.

    Arguments
    ---------
    None

    Returns
    -------
    std::string
        One of the states, either state_main_menu or state_module_c.
        TODO: Create a new type for states.
    */

    int operation;
    std::ostringstream oss;

    // Input
    std::cout << "Wybierz opcje: " << std::endl;
    operation = read_options_input(options_module_c.size());
    if (operation == 0) {
        return state_main_menu;
    }
    if (operation > 1 && grades.size() < 3) {
        std::cout << "Najpierw wprowadz przynajmniej 3 oceny." << std::endl;
        return state_module_c;
    }

    // Calculations, printing, history
    switch (operation) {
        case 1: {
            grades.clear();
            std::cout << "Wprowadz przynajmniej 3 oceny." << std::endl;
            std::cout << "Wprowadzaj oceny pojedynczo, a kazda zatwierdzaj enterem." << std::endl;
            while (true) {
                double new_grade = read_grades_input();
                grades.push_back(new_grade);
                if (grades.size() >= 3) {
                    std::cout << "Czy chcesz wprowadzic nastepna ocene?" << std::endl;
                    std::cout << "0 - NIE    1 - TAK" << std::endl;
                    int decision = read_options_input(2);
                    if (decision == 0) {
                        break;
                    } else {
                        continue;
                    }
                }
            }
            break;
        }
        case 2: {
            std::cout << "Srednia Twoich ocen wynosi: " << std::endl;
            double grades_sum = 0;
            for (unsigned int i = 0; i < grades.size(); i++) {
                grades_sum += grades[i];
                if (i == 0) {
                    std::cout << "(" << grades[i];
                } else {
                    std::cout << " + " << grades[i];
                }
                if (i == grades.size()-1) {
                    std::cout << ") / " << grades.size() << " = " << grades_sum / grades.size() << std::endl;
                }
            }
            auto avg_grade = grades_sum / grades.size();
            oss << "Srednia ocen: " << avg_grade;
            add_to_history(oss.str());
            add_to_module(name_module_c, false, oss.str());
            oss.str("");
            std::string grade_range_1 = (avg_grade < 3.0) ? "[2.00-2.99] - niedostateczny << Twoj wynik" : "[2.00-2.99] - niedostateczny";
            std::string grade_range_2 = (avg_grade < 4.0 && avg_grade >= 3.0) ? "[3.00-3.99] - dostateczny << Twoj wynik" : "[3.00-3.99] - dostateczny";
            std::string grade_range_3 = (avg_grade >= 4.0) ? "[4.00-5.00] - dobry << Twoj wynik" : "[4.00-5.00] - dobry";
            std::cout << grade_range_1 << std::endl;
            std::cout << grade_range_2 << std::endl;
            std::cout << grade_range_3 << std::endl;
            break;
        }
        case 3: {
            std::cout << "Najnizsza ocena jaka dostales/as to: " << *std::min_element(grades.begin(), grades.end()) << std::endl;
            oss << "Najnizsza ocena jaka dostales/as to: " << *std::min_element(grades.begin(), grades.end());
            add_to_history(oss.str());
            add_to_module(name_module_c, false, oss.str());
            oss.str("");
            break;
        }
        case 4: {
            std::cout << "Najwyzsza ocena jaka dostales/as to: " << *std::max_element(grades.begin(), grades.end()) << std::endl;
            oss << "Najwyzsza ocena jaka dostales/as to: " << *std::max_element(grades.begin(), grades.end());
            add_to_history(oss.str());
            add_to_module(name_module_c, false, oss.str());
            oss.str("");
            break;
        }
        case 5: {
            int amount_of_grades_below_3 = 0;
            for (double grade : grades) {
                if (grade < 3.0) {
                    amount_of_grades_below_3++;
                }
            }
            std::cout << "Masz " << amount_of_grades_below_3 << " ocen(y) ponizej 3.0." << std::endl;
            oss << "Masz " << amount_of_grades_below_3 << " ocen(y) ponizej 3.0.";
            add_to_history(oss.str());
            add_to_module(name_module_c, false, oss.str());
            oss.str("");
            if (amount_of_grades_below_3 == 0) {
                std::cout << "Gratulacje!" << std::endl;
            }
        }
    }

    return state_module_c;
}

